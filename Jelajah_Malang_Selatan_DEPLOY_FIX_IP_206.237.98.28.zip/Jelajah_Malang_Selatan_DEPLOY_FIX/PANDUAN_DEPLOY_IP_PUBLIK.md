# PANDUAN DEPLOY JELAJAH MALANG SELATAN — IP PUBLIK

Target website: http://206.237.98.28:8080
SSH: root@206.237.98.28 port 2204

## 1. Masuk ke VPS
Dari komputer Windows (PowerShell):
```powershell
ssh root@206.237.98.28 -p 2204
```
Jika SSH gagal, website belum bisa diperbaiki dari browser. Pastikan port 2204/TCP dibuka di firewall VPS/provider dan service SSH berjalan.

## 2. Masuk ke folder proyek
```bash
cd ~/jelajah-malang-selatan
pwd
ls -la
```
Pastikan ada `docker-compose.yml`, `deploy.sh`, `verify.sh`, `backend/`, `frontend/`, dan `db/`.

## 3. Siapkan file environment
```bash
cp -n .env.example .env
nano .env
```
Ganti semua nilai `GANTI_...` dengan rahasia acak. Buat secret dengan:
```bash
openssl rand -hex 32
```
Gunakan nilai berbeda untuk DB_PASSWORD, DB_ROOT_PASSWORD, SECRET_KEY, dan API_KEY.
Pastikan baris berikut ada:
```env
HTTP_PORT=8080
CORS_ORIGINS=http://206.237.98.28:8080
COOKIE_SECURE=false
```
`COOKIE_SECURE=false` hanya untuk HTTP sementara. Untuk produksi, pasang HTTPS dan ubah menjadi `true`.

## 4. Deploy
```bash
chmod +x deploy.sh verify.sh
./deploy.sh
```
Script memvalidasi Docker Compose, membangun container, menunggu healthcheck MariaDB/backend/frontend, menerapkan skema SQL, lalu menguji website dan API.

## 5. Verifikasi
```bash
docker compose ps
docker compose port frontend 80
curl -i http://127.0.0.1:8080/
curl -i http://127.0.0.1:8080/api/health
./verify.sh
```
URL browser: `http://206.237.98.28:8080`

## 6. Jika tetap ERR_CONNECTION_REFUSED
Jalankan dan kirim outputnya:
```bash
docker compose ps
docker compose logs --tail=100 mariadb backend frontend
ss -ltnp | grep -E ':2204|:8080'
ufw status verbose
docker compose port frontend 80
curl -v http://127.0.0.1:8080/
```
Jika `curl` localhost berhasil tetapi akses dari internet gagal, periksa firewall provider/cloud security group dan izinkan TCP 8080. Jangan membuka port database 3306 atau backend 5000 ke internet.

## Catatan
- Jangan menjalankan `docker compose down -v`; itu dapat menghapus volume database.
- Jangan kirim file `.env`, password, atau API_KEY.
- `docker compose` memetakan port host 8080 ke port 80 di container Nginx.
- Port SSH 2204 berbeda dari port website 8080.
