#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

if ! command -v docker >/dev/null 2>&1; then
  echo "ERROR: Docker belum terpasang. Pasang Docker Engine dan Compose plugin terlebih dahulu."
  exit 1
fi
if ! docker compose version >/dev/null 2>&1; then
  echo "ERROR: Docker Compose plugin tidak tersedia."
  exit 1
fi
if ! command -v openssl >/dev/null 2>&1; then
  echo "ERROR: openssl diperlukan untuk membuat secret."
  exit 1
fi

if [[ ! -f .env ]]; then
  cat > .env <<EOF
DB_NAME=jelajah_malang_selatan
DB_USER=jms_app
DB_PASSWORD=$(openssl rand -hex 32)
DB_ROOT_PASSWORD=$(openssl rand -hex 32)
SECRET_KEY=$(openssl rand -hex 64)
API_KEY=$(openssl rand -hex 64)
COOKIE_SECURE=false
HTTP_PORT=8080
CORS_ORIGINS=http://206.237.98.28:8080
EOF
  chmod 600 .env
  echo "File .env dibuat dengan secret acak dan izin 600."
else
  chmod 600 .env
  echo "Menggunakan .env yang sudah ada; pastikan semua password/secret sudah diganti."
fi

HTTP_PORT_VALUE="$(grep -E '^HTTP_PORT=' .env | tail -n1 | cut -d= -f2-)"
HTTP_PORT_VALUE="${HTTP_PORT_VALUE:-8080}"
if command -v ss >/dev/null 2>&1 && ss -ltnH | awk '{print $4}' | grep -Eq "(:|\\])${HTTP_PORT_VALUE}$"; then
  echo "ERROR: port ${HTTP_PORT_VALUE} sedang dipakai proses lain. Bebaskan port itu atau ubah HTTP_PORT di .env (contoh 8080), lalu jalankan lagi."
  exit 1
fi

echo "[1/5] Validasi konfigurasi Docker..."
docker compose config >/dev/null

echo "[2/5] Build dan jalankan layanan..."
docker compose up -d --build

echo "[3/5] Menunggu MariaDB dan backend sehat..."
for i in $(seq 1 90); do
  DB_STATE="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' jms-mariadb 2>/dev/null || true)"
  API_STATE="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' jms-backend 2>/dev/null || true)"
  WEB_STATE="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}{{.State.Status}}{{end}}' jms-nginx 2>/dev/null || true)"
  if [[ "$DB_STATE" == "healthy" && "$API_STATE" == "healthy" && "$WEB_STATE" == "healthy" ]]; then
    break
  fi
  sleep 5
done

if [[ "$DB_STATE" != "healthy" || "$API_STATE" != "healthy" || "$WEB_STATE" != "healthy" ]]; then
  echo "ERROR: Layanan belum semuanya healthy setelah menunggu 450 detik."
  echo "Status MariaDB: $DB_STATE"
  echo "Status backend: $API_STATE"
  echo "Status frontend: $WEB_STATE"
  docker compose ps
  docker compose logs --tail=100 mariadb backend frontend
  exit 1
fi

echo "[4/5] Terapkan skema idempotent (aman untuk volume DB yang sudah ada)..."
for sql in db/init/001-auth-users.sql db/init/001-core-schema.sql db/init/002-app-support.sql; do
  docker compose exec -T mariadb sh -c \
    'mariadb -u"$MARIADB_USER" -p"$MARIADB_PASSWORD" "$MARIADB_DATABASE"' < "$sql"
done

echo "[5/5] Tes endpoint website dan API..."
HTTP_PORT_VALUE="$(grep -E '^HTTP_PORT=' .env | tail -n1 | cut -d= -f2-)"
HTTP_PORT_VALUE="${HTTP_PORT_VALUE:-8080}"
if ! curl -fsS "http://127.0.0.1:${HTTP_PORT_VALUE}/" >/dev/null; then
  echo "ERROR: Frontend belum merespons. Periksa: docker compose logs --tail=100"
  docker compose ps
  exit 1
fi
if ! curl -fsS "http://127.0.0.1:${HTTP_PORT_VALUE}/api/health"; then
  echo
  echo "ERROR: API/database belum sehat. Periksa log backend dan MariaDB."
  docker compose logs --tail=100 backend mariadb
  exit 1
fi

if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${HTTP_PORT_VALUE}/tcp" || true
fi

echo
echo "DEPLOYMENT SELESAI."
if [[ "$HTTP_PORT_VALUE" == "80" ]]; then
  echo "Website: http://206.237.98.28"
else
  echo "Website: http://206.237.98.28:${HTTP_PORT_VALUE}"
fi
echo "Status:  docker compose ps"
echo "Log:     docker compose logs -f --tail=100"
echo "Buat admin pertama:"
echo "  docker compose exec backend python manage_users.py create --username admin --name 'Admin Utama' --role super"
echo
echo "PENTING: jika URL publik belum dapat dibuka, firewall/provider/NAT harus meneruskan TCP port ${HTTP_PORT_VALUE} ke server ini."
echo "Jangan publikasikan .env, API_KEY, password, atau port database."
