# Jelajah Malang Selatan — paket deployment Docker

Paket ini menyiapkan frontend Nginx, backend Flask/Gunicorn, MariaDB, skema inti minimum, dan scraper Google Maps berbasis Playwright.

## Target deployment

- Server: `206.237.98.28`
- SSH: port `2204` (tetap khusus SSH; jangan diubah)
- Website: `http://206.237.98.28` (port TCP 80)
- Docker mempublikasikan Nginx pada `0.0.0.0:80`.
- Backend (5000) dan MariaDB (3306) hanya berada di jaringan internal Docker.

> Penting: konfigurasi aplikasi dapat disiapkan untuk IP publik, tetapi file proyek tidak dapat mengatur firewall provider, NAT, security group, atau port forwarding di luar server. Agar URL publik dapat dibuka, TCP port 80 harus diizinkan dan diarahkan ke server ini. Pemeriksaan sebelumnya dari lingkungan ChatGPT menerima `connection refused` pada port 80 dan 2204, jadi akses publik harus dites lagi setelah deployment.

## 1. Upload dan ekstrak di server

Dari komputer Anda, unggah ZIP ke server (gunakan SCP dengan port SSH 2204), lalu SSH:

```bash
scp -P 2204 Jelajah_Malang_Selatan_Docker_DEPLOY.zip root@206.237.98.28:/root/
ssh root@206.237.98.28 -p 2204
```

Di server:

```bash
apt-get update
apt-get install -y unzip curl openssl
mkdir -p /opt/jelajah-malang-selatan
unzip -o /root/Jelajah_Malang_Selatan_Docker_DEPLOY.zip -d /opt/
cd /opt/jelajah-malang-selatan
```

Pastikan Docker Engine dan plugin Docker Compose tersedia:

```bash
docker --version
docker compose version
```

Jika belum terpasang, instal Docker Engine dan Compose plugin dari dokumentasi resmi Docker untuk distro server Anda terlebih dahulu.

## 2. Deploy otomatis

```bash
chmod +x deploy.sh
./deploy.sh
```

Script akan:
- membuat `.env` dengan password dan secret acak jika belum ada;
- membatasi permission `.env` menjadi `600`;
- memvalidasi konfigurasi Compose;
- membangun image dan menjalankan tiga layanan;
- menunggu healthcheck;
- menerapkan ulang SQL idempotent agar database volume lama juga mendapat tabel yang diperlukan;
- menguji frontend dan endpoint health API;
- membuka port 80 di UFW jika UFW aktif.

Jangan jalankan `docker compose down -v`; perintah itu menghapus volume database.

## 3. Buat akun admin pertama

```bash
docker compose exec backend python manage_users.py create --username admin --name "Admin Utama" --role super
```

Masukkan password minimal 12 karakter saat diminta. Jangan gunakan `--password` agar password tidak tersimpan di riwayat shell.

## 4. Tes

Dari server:

```bash
./verify.sh
curl -i http://127.0.0.1/
curl -i http://127.0.0.1/api/health
```

Dari komputer lain:

```text
http://206.237.98.28
```

Jika tes lokal server berhasil tetapi tes dari internet gagal, minta administrator jaringan/provider membuka TCP `80` dan melakukan NAT/port-forward ke IP privat server port `80`. Jangan membuka port 5000 atau 3306 ke internet.

## 5. Scraper Google Maps

Tombol scraper backend sekarang menggunakan endpoint `/api/scrape-maps`, menerima header `X-Admin-Token`, memvalidasi token di backend, menjalankan Playwright Chromium di container backend, lalu memasukkan hasil ke antrean `menunggu_review` MariaDB melalui `/api/scraper/import`.

Token yang dimasukkan pada kolom token admin backend adalah nilai `API_KEY` pada file `.env` di server. Jangan pernah membagikan file `.env` atau token tersebut.

Scraper bergantung pada akses keluar internet dan perubahan struktur Google Maps; Google dapat membatasi atau mengubah halaman sehingga hasil scraping tidak dijamin selalu tersedia.

## 6. Database dan data aplikasi

- Skema `users`, `desa`, `mata_uang`, `resort_penginapan`, `pengaturan_banner`, `pengaturan_website`, dan `hasil_scraping_maps` dibuat secara idempotent.
- Skema `desa` dan `resort_penginapan` adalah skema inti minimum yang disesuaikan dengan kolom yang dipakai API di proyek ini. Jika Anda memiliki dump database asli yang lebih lengkap, backup dahulu lalu gabungkan migrasinya sebelum produksi.
- Beberapa modul frontend lama masih menyimpan konten di `localStorage` browser. Data tersebut tidak otomatis tersinkron antar perangkat/pengguna. Endpoint API login dan resort tidak otomatis mengubah semua modul localStorage menjadi multi-user.
- SQL init otomatis MariaDB hanya berjalan saat volume pertama dibuat; `deploy.sh` menerapkan ulang file SQL dengan aman pada setiap deployment.

## 7. Perintah operasional

```bash
docker compose ps
docker compose logs -f --tail=100
docker compose restart
docker compose down
```

Backup database:

```bash
docker compose exec mariadb sh -c 'mariadb-dump -u root -p"$MARIADB_ROOT_PASSWORD" "$MARIADB_DATABASE"' > backup-jelajah.sql
```

Simpan backup dan `.env` di lokasi privat.

## 8. HTTPS produksi

Paket ini menggunakan HTTP pada port 80 untuk deployment awal. Untuk penggunaan publik jangka panjang, gunakan domain dan reverse proxy/sertifikat TLS, lalu ubah `COOKIE_SECURE=true` setelah HTTPS aktif. Jangan aktifkan secure cookie sebelum HTTPS tersedia karena sesi login tidak akan terkirim lewat HTTP.
