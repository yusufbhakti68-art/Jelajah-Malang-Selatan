-- Skema inti minimum yang dipakai API resort dan antrean scraper.
-- Dibuat idempotent agar aman untuk inisialisasi database baru.
CREATE TABLE IF NOT EXISTS mata_uang (
    id_mata_uang VARCHAR(10) NOT NULL PRIMARY KEY,
    nama_mata_uang VARCHAR(100) NOT NULL,
    simbol VARCHAR(10) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO mata_uang (id_mata_uang, nama_mata_uang, simbol)
VALUES ('IDR', 'Rupiah Indonesia', 'Rp')
ON DUPLICATE KEY UPDATE nama_mata_uang=VALUES(nama_mata_uang), simbol=VALUES(simbol);

CREATE TABLE IF NOT EXISTS desa (
    id_desa CHAR(36) NOT NULL PRIMARY KEY,
    nama_desa VARCHAR(180) NOT NULL,
    kecamatan VARCHAR(180) NULL,
    kabupaten VARCHAR(180) NULL,
    deskripsi TEXT NULL,
    foto_url VARCHAR(1000) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_desa_nama (nama_desa),
    KEY idx_desa_kecamatan (kecamatan)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS resort_penginapan (
    id_resort CHAR(36) NOT NULL PRIMARY KEY,
    id_mata_uang VARCHAR(10) NOT NULL DEFAULT 'IDR',
    nama_resort VARCHAR(255) NOT NULL,
    jenis VARCHAR(100) NULL,
    harga_per_malam DECIMAL(15,2) NULL,
    kontak_reservasi VARCHAR(100) NULL,
    alamat TEXT NULL,
    id_desa CHAR(36) NULL,
    latitude DECIMAL(10,7) NULL,
    longitude DECIMAL(10,7) NULL,
    foto_url VARCHAR(1000) NULL,
    link_google_maps VARCHAR(1000) NULL,
    status_publikasi VARCHAR(30) NOT NULL DEFAULT 'draft',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_resort_nama (nama_resort),
    KEY idx_resort_status (status_publikasi),
    KEY idx_resort_desa (id_desa),
    CONSTRAINT fk_resort_mata_uang FOREIGN KEY (id_mata_uang)
      REFERENCES mata_uang(id_mata_uang) ON UPDATE CASCADE,
    CONSTRAINT fk_resort_desa FOREIGN KEY (id_desa)
      REFERENCES desa(id_desa) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
