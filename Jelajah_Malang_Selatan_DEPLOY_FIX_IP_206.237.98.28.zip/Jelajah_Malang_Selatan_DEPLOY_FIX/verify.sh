#!/usr/bin/env bash
set -u
cd "$(dirname "$0")"
if [[ -f .env ]]; then
  HTTP_PORT="$(grep -E '^HTTP_PORT=' .env | tail -n1 | cut -d= -f2-)"
fi
HTTP_PORT="${HTTP_PORT:-8080}"
echo "=== Docker containers ==="
docker compose ps
echo
echo "=== Frontend ==="
curl -sS -o /dev/null -w "HTTP %{http_code}\n" "http://127.0.0.1:${HTTP_PORT}/" || true
echo
echo "=== Backend + database ==="
curl -sS "http://127.0.0.1:${HTTP_PORT}/api/health" || true
echo
echo "=== Recent logs ==="
docker compose logs --tail=40 mariadb backend frontend
