# Jelajah Malang Selatan — paket Docker yang diperbaiki

Paket ini menjalankan frontend HTML melalui Nginx, backend Flask/Gunicorn, dan MariaDB.

## Perubahan pada versi perbaikan

- Port host default website diubah menjadi **8080**, bukan 2204. Port 2204 pada server pengguna dipakai untuk SSH (`ssh root@IP_PUBLIK -p 2204`), sehingga tidak boleh dipakai bersamaan oleh website pada IP publik yang sama.
- Nginx tetap mendengarkan port 80 di dalam container; Docker memetakan `HTTP_PORT` host ke port 80 container.
- Healthcheck MariaDB, backend, dan frontend ditambahkan. Frontend menunggu backend sehat.
- Tabel pendukung banner dan antrean scraper dibuat melalui `db/init/002-app-support.sql` pada inisialisasi database baru.
- Dokumentasi akses lokal dan kebutuhan port forwarding publik diperjelas.

## 1. Prasyarat

Ubuntu/Linux dengan Docker Engine dan Docker Compose plugin:

```bash
docker --version
docker compose version
```

Ekstrak ZIP, lalu masuk ke folder `jelajah-malang-selatan-docker`.

## 2. Siapkan `.env`

```bash
cp .env.example .env
```

Buat nilai rahasia berbeda untuk setiap variabel:

```bash
openssl rand -hex 32
```

Edit `.env` dengan editor yang tersedia, misalnya `nano .env` (pasang dengan `apt update && apt install nano -y` bila belum ada).

Contoh nilai konfigurasi (GANTI semua password dan secret):

```env
DB_NAME=jelajah_malang_selatan
DB_USER=jms_app
DB_PASSWORD=GANTI_PASSWORD_DATABASE
DB_ROOT_PASSWORD=GANTI_PASSWORD_ROOT
SECRET_KEY=GANTI_SECRET_RANDOM_MINIMAL_32_KARAKTER
API_KEY=GANTI_API_KEY_RANDOM_MINIMAL_32_KARAKTER
COOKIE_SECURE=false
HTTP_PORT=8080
CORS_ORIGINS=http://localhost:8080
```

Jangan menyalin contoh password/secret ke server produksi. Jangan mengirim file `.env` dan jangan mengunggahnya ke Git.

## 3. Jalankan aplikasi

```bash
docker compose config
docker compose up -d --build
docker compose ps
```

Lihat log bila ada container yang belum sehat:

```bash
docker compose logs --tail=100 mariadb backend frontend
```

Tes website dari server itu sendiri:

```bash
curl -I http://127.0.0.1:8080/
curl -I http://10.141.70.81:8080/
```

Tes backend melalui Nginx:

```bash
curl http://127.0.0.1:8080/api/health
```

Hasil sehat yang diharapkan: HTTP 200 dan JSON `{"database":"connected","status":"ok"}`.

Buka di Chrome dari komputer yang memiliki jalur jaringan ke server:

```text
http://IP-LOKAL-SERVER:8080
```

Contoh berdasarkan alamat server pada sesi sebelumnya:

```text
http://10.141.70.81:8080
```

Jika laptop berada di jaringan berbeda (contoh laptop `10.15.36.103/16`, server `10.141.70.81/24`), akses lokal mungkin gagal tanpa routing antarjaringan. Tes dari Windows:

```powershell
Test-NetConnection 10.141.70.81 -Port 8080
```

`TcpTestSucceeded : True` berarti port dapat dijangkau. Ping timeout saja tidak selalu berarti web mati; yang lebih penting adalah tes TCP port.

## 4. Akses melalui IP publik (penting untuk server sekolah)

Port SSH publik pengguna adalah:

```bash
ssh root@206.237.98.28 -p 2204
```

Dengan demikian, **jangan gunakan port publik 2204 untuk website**. Jangan mengubah atau mematikan SSH.

Website pada versi ini mendengarkan di port host server **8080**. Agar bisa diakses dari internet, admin jaringan/guru harus menyediakan port publik lain dan mengarahkan TCP ke:

```text
IP publik : PORT_WEB_PUBLIK
          -> IP privat server : 8080
```

Misalnya jika guru menyetujui port publik 2205:

```text
206.237.98.28:2205 -> 10.141.70.81:8080
```

Alamat browser menjadi `http://206.237.98.28:2205`. Angka 2205 hanya contoh, bukan port yang sudah tersedia. Minta guru mengonfirmasi port publik yang dialokasikan dan aturan NAT/port forwarding. Jika guru tidak menyediakan port atau routing, perubahan file Docker tidak dapat membuat IP publik dapat diakses dari luar.

Jangan membuka port 5000 (backend) atau 3306 (MariaDB) ke internet. Hanya port web yang perlu diarahkan ke Nginx.

## 5. Buat akun admin pertama

Setelah database sehat:

```bash
docker compose exec backend python manage_users.py create --username admin --name "Admin Utama" --role super
```

Password diminta secara interaktif. Perintah lain:

```bash
docker compose exec backend python manage_users.py list
docker compose exec backend python manage_users.py status --username admin --active no
```

Role yang didukung: `super`, `desa`, `damri`.

## 6. Database dan batasan skema proyek

- `001-auth-users.sql` membuat tabel login `users`.
- `002-app-support.sql` membuat tabel `pengaturan_banner`, `pengaturan_website`, dan `hasil_scraping_maps`.
- ZIP sumber **tidak menyertakan skema inti** tabel `desa`, `resort_penginapan`, serta tabel konten lain. Karena struktur aslinya tidak tersedia dalam ZIP, paket ini tidak mengarang skema tersebut. Endpoint resort dan persetujuan hasil scraper yang bergantung pada tabel itu belum siap dipakai sampai skema inti yang benar diimpor.
- SQL dalam `db/init` hanya dijalankan otomatis saat volume MariaDB dibuat pertama kali. Jika volume database lama sudah ada, file SQL baru tidak otomatis dijalankan. Untuk menerapkan `002-app-support.sql` pada database lama, jalankan:

  ```bash
  docker compose exec -T mariadb sh -c 'mariadb -u"$MARIADB_USER" -p"$MARIADB_PASSWORD" "$MARIADB_DATABASE"' < db/init/002-app-support.sql
  ```

- Banyak data konten pada HTML sumber masih menggunakan `localStorage`; data tersebut tersimpan di browser/perangkat masing-masing dan belum otomatis tersinkron antar pengguna.
- UI scraper HTML sumber memanggil endpoint `/api/scrape-maps`, sedangkan backend yang disertakan menyediakan alur impor `/api/scraper/import`. Jadi tombol scraper langsung dari UI belum terintegrasi. `backend/scraper.py` merupakan skrip terpisah dan membutuhkan dependensi browser tersendiri; jangan menganggapnya berjalan di container backend standar.
- Endpoint `/api/resorts` memerlukan tabel inti `desa` dan `resort_penginapan`. Endpoint tersebut akan mengembalikan error sampai skema inti tersedia.

## 7. HTTPS dan keamanan

Paket ini hanya menyiapkan HTTP untuk pengujian. Untuk penggunaan publik yang sebenarnya, gunakan domain dan sertifikat TLS pada Nginx/reverse proxy, lalu aktifkan `COOKIE_SECURE=true`. Jangan mengaktifkan `COOKIE_SECURE=true` sebelum HTTPS benar-benar tersedia karena cookie login tidak akan dikirim melalui HTTP.

Ganti semua secret yang pernah dibagikan atau digunakan bersama orang lain. Batasi akses server dan buat backup database secara berkala.

## 8. Operasional dan backup

```bash
docker compose logs -f
docker compose restart
docker compose down
```

**Jangan menjalankan `docker compose down -v`** kecuali memang ingin menghapus volume dan seluruh data MariaDB.

Backup:

```bash
docker compose exec mariadb sh -c 'mariadb-dump -u root -p"$MARIADB_ROOT_PASSWORD" "$MARIADB_DATABASE"' > backup-jelajah.sql
```

Simpan backup `.sql` dan salinan `.env` di lokasi aman yang tidak dipublikasikan.
